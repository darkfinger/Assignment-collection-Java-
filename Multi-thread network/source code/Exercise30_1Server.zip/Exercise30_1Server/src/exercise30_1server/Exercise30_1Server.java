/*
 * Prof: Dr. Dehkhoda
 * Student's Name: Kapanga David
 * Date: 06/05/2017
 * Assignment: CS 56 Project on multi-treading server
 * Server side code source
 */
package exercise30_1Server;

import java.io.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author david
 */
public class Exercise30_1Server extends Application {

    float[] data = new float[3];
    TextArea display = new TextArea();
    
    @Override
    public void start(Stage primaryStage) throws Exception {

        display.setPrefSize(20, 80);
        display.setEditable(false);
        new Thread(() -> {
            try {
                // Create a server socket
                ServerSocket serverSocket = new ServerSocket(8186);

                while (true) {
                    // Listen for a new connection request
                    Socket socket = serverSocket.accept();

                    // Create and start a new thread for the connection
                    new Thread(new HandleAClient(socket)).start();
                }
            } catch (IOException ex) {
                System.err.println(ex);
            }
        }).start();

        StackPane root = new StackPane();
        root.getChildren().add(display);
        Scene scene = new Scene(root, 420, 210);
        primaryStage.setTitle("Mutli-Thread Server");
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    class HandleAClient implements Runnable {

        private Socket socket; // A connected socket
        //Construct a thread         
        public HandleAClient(Socket socket) {
            this.socket = socket;
        }
        //run the thread
        public void run() {
            ObjectInputStream inputFromClient = null;
            try {
                //Create data input and output streams
                inputFromClient = new ObjectInputStream(
                        socket.getInputStream());
                DataOutputStream outputToClient = new DataOutputStream(
                        socket.getOutputStream());
                try {
                    // Continuously serve the client
                    while (true) {
                        try {
                            // Receive data array from the client
                            data = (float[]) inputFromClient.readObject();
                            //compute
                            float n = data[1] * 12;
                            float i = (data[0] / 100) / 12;
                            double d =(Math.pow((1 + i), n) - 1) / (i * (Math.pow((1 + i), n)));                            
                            float p = data[2] /(float) d;
                            float total = p * n;
                            
                            //display the process on the textArea
                            display.setText("data reicive: \n Interest=" + data[0] + "%, year(s)=" + data[1] + ", Amount= " + data[2] + "$ \n"
                                    + "time n is " + n + "(years times 12 monthly payments per year)\n"
                                    + "interest i is " + i + "(% in decimal and divided by 12 monthly payments per year)\n"
                                    + "discount factor d is " + d + "(by the formula: {[(1 + i) ^n] - 1} / [i(1 + i)^n]) \n"
                                    + "Monthly P is " + p + "(Amount divided by d) \n"
                                    + "Total is " + total + "(monthly payment multiply by nomber of month) \n");
                            // Send back the result to the client
                            outputToClient.writeFloat(p);
                            outputToClient.writeFloat(total);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(Exercise30_1Server.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (IOException ex) {
                Logger.getLogger(Exercise30_1Server.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    inputFromClient.close();
                    socket.close();
                } catch (IOException ex) {
                    Logger.getLogger(Exercise30_1Server.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
