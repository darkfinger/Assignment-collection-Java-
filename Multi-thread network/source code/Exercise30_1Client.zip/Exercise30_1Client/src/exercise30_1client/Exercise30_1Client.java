/*
 * Prof: Dr. Dehkhoda
 * Student's Name: Kapanga David
 * Date: 06/05/2017
 * Assignment: CS 56 Project on multi-treading server
 * Client side code source
 */
package exercise30_1client;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author david
 */
public class Exercise30_1Client extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        String host = "localhost";
        //creating an array objet to send date from form to the server
        float[] data = new float[3];
        //creating the form
        Label interestLabel = new Label("Annual Interest Rate");
        Label numbOfYearLabel = new Label("Number Of Years");
        Label loanAmountLabel = new Label("Loan Amount");
        TextField interestTextField = new TextField();
        TextField numbOfYearTextField = new TextField();
        TextField loanAmountTextField = new TextField();
        TextArea display = new TextArea();
        display.setPrefSize(20, 80);
        display.setEditable(false);
        Button btn = new Button();
        btn.setText("Sbumit");
        //adding an action on the submit button
        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                try {
                    // Establish connection with the server
                    Socket socket = new Socket(host, 8186);

                    // Create an output stream to the server
                    ObjectOutputStream toServer = new ObjectOutputStream(
                            socket.getOutputStream());
                    DataInputStream inputFromServer = new DataInputStream(
                            socket.getInputStream());
                    // Getting data from the form field
                    try {
                        //trying to convert data to double value, if not valide data catch the exception and show alert box
                        data[0] = Float.parseFloat(interestTextField.getText().trim());
                        data[1] = Float.parseFloat(numbOfYearTextField.getText().trim());
                        data[2] = Float.parseFloat(loanAmountTextField.getText().trim());
                        //sending the array contaning all data from the form
                        toServer.writeObject(data);
                        System.out.println("sending success");
                        //getting an answer from server
                        float p = inputFromServer.readFloat();
                        //getting second answer from server
                        float total = inputFromServer.readFloat();
                        //display the informations on the textArea
                        display.setText("In " + data[1] + "year(s) with " + data[0] + "% interest on " + data[2] + "$ \nThe monthly payement is : " + String.valueOf(p)
                                + "\nThe Total payment is " + total);
                    } catch (Exception e) {
                        //alert in case of user enter string value or any invalide data that can't be convert to double
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error Dialog");
                        alert.setHeaderText("Operation can't be performed");
                        alert.setContentText("please insert valide data in each fiels");
                        alert.showAndWait();
                    }

                    toServer.close();
                    socket.close();

                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        //creating a grid layout to contain each node of the form
        GridPane grid;
        grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(10, 10, 10, 10));

        //Insert nodes in the greide
        grid.add(interestLabel, 0, 0);
        grid.add(interestTextField, 1, 0);
        grid.add(numbOfYearLabel, 0, 1);
        grid.add(numbOfYearTextField, 1, 1);
        grid.add(loanAmountLabel, 0, 2);
        grid.add(loanAmountTextField, 1, 2);
        grid.add(btn, 2, 0, 1, 3);
        grid.add(display, 0, 3, 3, 1);

        //creat the root Pane
        StackPane root = new StackPane();
        //add the gridPane to the root pane
        root.getChildren().addAll(grid);
        //creat a scene        
        Scene scene = new Scene(root, 420, 210);
        //setting up the stage
        primaryStage.setTitle("Mutli-Thread Server");
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
